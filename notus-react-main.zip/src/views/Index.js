/*eslint-disable*/
import React, { useEffect, useState } from "react";
import IndexNavbar from "components/Navbars/IndexNavbar.js";
import Footer from "components/Footers/Footer.js";
import Medical_Video from "../assets/img/Medical_Video.mp4";
import img1 from "../assets/img/HomePage1.png";
import img2 from "../assets/img/HomePage2.png";
import img3 from "../assets/img/HomePage4.png";
import img4 from "../assets/img/HomePage5.jpg";

import scrollBackground from "../assets/img/17973908.jpg";

export default function Index() {
  const images = [img1, img2, img3, img4];
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % images.length);
    }, 2000);
    return () => clearInterval(interval);
  }, [images.length]);

  useEffect(() => {
    const style = document.createElement("style");
    style.textContent = `
      @media (max-width: 768px) {
        .header-section {
          padding: 2rem 1rem !important;
          height: 60vh !important;
          width: 100% !important;
        }
        .header-heading {
          font-size: clamp(24px, 5vw, 36px) !important;
          margin-bottom: 16px !important;
        }
        .header-paragraph {
          font-size: clamp(16px, 3vw, 18px) !important;
        }
        .philosophy-section {
          flex-direction: column !important;
          padding: 1rem !important;
        }
        .philosophy-image {
          width: 100% !important;
          max-width: 100% !important;
          margin: 0 auto !important;
          padding: 0 1rem !important;
        }
        .philosophy-image img {
          width: 100% !important;
          height: auto !important;
          max-height: 50vh !important;
          object-fit: cover !important;
        }
        .philosophy-content {
          width: 100% !important;
          padding: 1rem !important;
        }
        .philosophy-heading {
          font-size: clamp(24px, 5vw, 32px) !important;
        }
        .philosophy-text {
          font-size: clamp(16px, 3vw, 18px) !important;
        }
        .sets-apart-section {
          padding: 2rem 0 !important;
          margin-top: 4% !important;
        }
        .sets-apart-video {
          width: 100% !important;
          height: auto !important;
          max-height: 40vh !important;
          top: 0 !important;
          z-index: 1 !important;
        }
        .sets-apart-heading {
          font-size: clamp(24px, 5vw, 28px) !important;
          margin-left: 0 !important;
          padding: 0 1rem 1rem 1rem !important;
        }
        .sets-apart-carousel {
          overflow-x: auto !important;
          display: flex !important;
          flex-direction: row !important;
          scroll-behavior: smooth !important;
          -webkit-overflow-scrolling: touch;
          padding: 0 1rem !important;
          gap: 16px !important;
        }
        .sets-apart-carousel::-webkit-scrollbar {
          display: none;
        }
        .sets-apart-carousel-container {
          display: flex !important;
          width: 400px !important;
          gap: 16px !important;
          padding-left: 8px !important;
        }
        .sets-apart-card {
          width: 280px !important;
          flex: 0 0 280px !important;
          height: auto !important;
          min-height: 250px !important;
          margin: 0 !important;
        }
        .sets-apart-card-title {
          font-size: clamp(14px, 3vw, 16px) !important;
          // color:"white"
        }
        .sets-apart-card-description {
          font-size: clamp(12px, 2.5vw, 14px) !important;
        }
      }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  const services = [
    {
      title: "Personalized Longevity Protocols",
      description:
        "Each plan begins with deep diagnostics — genomic, metabolic, hormonal, and cellular — ensuring every recommendation is crafted for your body’s unique blueprint. Our AI-enabled insights help analyze multi-omic data and devise a customized health plan journey for you.",
      bgColor: "#a33e7a",
    },
    {
      title: "Elite Medical Team",
      description:
        "Our board-certified anti-aging specialists, aesthetic physicians, and longevity researchers bring global experience and precision into every client journey.",
      bgColor: "#bec989",
    },
    {
      title: "Luxury Meets Innovation",
      description:
        "From state-of-the-art therapies like red-light rejuvenation and HBOT support to nutritional optimization and advanced aesthetics — we offer world-class interventions in tranquil, private spaces.",
      bgColor: "#b77e5a",
    },
    {
      title: "Complete Discretion",
      description:
        "We work exclusively with a select clientele who value privacy, performance, and premium care.",
      bgColor: "#c94c4e",
    },
  ];

  return (
    <>
      <IndexNavbar fixed />
      <section className="header relative pt-16 max-h-860-px">
        <div
          className="header-section"
          style={{
            marginTop: "20px",
            padding: "3rem 10rem",
            color: "white",
            textAlign: "center",
            backgroundImage: `url(${images[currentIndex]})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            transition: "background-image 1s ease-in-out",
            position: "relative",
            height: "80vh",
            width: "98.9vw",
            maxWidth: "100%",
          }}
        >
          <div
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              background: "rgba(0,0,0,0.5)",
              borderRadius: "8px",
            }}
          ></div>
          <div style={{ position: "relative", zIndex: 1 }}>
            <h1
              className="header-heading"
              style={{
                fontSize: "42px",
                fontWeight: "bold",
                marginBottom: "20px",
              }}
            >
              Redefining the Future of Aging <br />One Individual at a Time
            </h1>
            <p
              className="header-paragraph"
              style={{
                fontSize: "22px",
              }}
            >
              At Aarogyam, we believe aging is no longer a destiny — it’s a choice.
              Built on the pillars of medical innovation, bespoke care, and
              integrated healthcare experience, we offer the most advanced
              anti-aging and longevity solutions hyper personalized exclusively for
              those who demand the very best. <br />
              <br />
              Our mission is to elevate the aging experience by integrating
              cutting-edge diagnostics, precision medicine, and holistic wellness —
              all delivered in a discreet, luxurious environment tailored to your
              lifestyle.
            </p>
          </div>
        </div>
                <div  style={{
    backgroundImage: "linear-gradient(to bottom, #f1f5f9, #cbd5e1)", // light gray → darker gray
  }} className=" py-5 md:py-10 px-5 md:px-10 font-bold text-4xl text-center">About Us</div>

      </section>

      <section
        className="mt-50 md:mt-50 relative bg-blueGray-100"
        style={{ marginTop: "6%" }}
      >
        <div
          className="-mt-20 top-0 bottom-auto left-0 right-0 w-full absolute h-20"
          style={{ transform: "translateZ(0)" }}
        >
          <svg
            className="absolute bottom-0 overflow-hidden"
            xmlns="http://www.w3.org/2000/svg"
            preserveAspectRatio="none"
            version="1.1"
            viewBox="0 0 2560 100"
            x="0"
            y="0"
          >
            <polygon
              className="text-blueGray-100 fill-current"
              points="2560 0 2560 100 0 100"
            ></polygon>
          </svg>
        </div>
        <div className="container mx-auto" style={{ paddingTop: "1%" }}>
          <div className="flex flex-wrap items-center philosophy-section">
            <div className="w-10/12 md:w-6/12 lg:w-4/12 px-12 md:px-4 mr-auto ml-auto -mt-32 philosophy-image">
              <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded-lg bg-lightBlue-500">
                <img
                  alt="..."
                  src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=700&q=80"
                  className="w-full align-middle rounded-t-lg"
                />
              </div>
            </div>

            <div
              className="w-full md:w-6/12 philosophy-content"
              style={{ fontSize: "22px", color: "#6084a4" }}
            >
              <h2
                className="philosophy-heading"
                style={{ fontSize: "35px", color: "#6084a4", fontWeight: "bold" }}
              >
                Our Philosophy
              </h2>
              <div className="philosophy-text">
                We don’t treat symptoms. <br />
                We decode your biology, optimize your healthspan, and craft a path
                to lifelong vitality — as unique as your DNA. From cellular
                rejuvenation to hormonal balance, from aesthetic refinement to
                deep-rooted wellness, our approach is comprehensive,
                evidence-backed, and always personal.
              </div>
            </div>
          </div>
        </div>

        <div
          className="sets-apart-section"
          style={{
            position: "relative",
            // background:
            //   "linear-gradient(to left bottom, #fffcff, #fbfaff, #effbff, #e0fdff, #d5fefd)",
            backgroundImage: `url(${scrollBackground})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            overflow: "visible",
            paddingTop: "50px",
            marginTop: "8%",
            paddingBottom: "80px",
          }}
        >
          <video
            className="sets-apart-video"
            style={{
              position: "absolute",
              top: "-30px",
              left: 0,
              width: "45%",
              height: "65%",
              objectFit: "cover",
              borderTopRightRadius: "24px",
              zIndex: 1,
            }}
            autoPlay
            loop
            muted
            playsInline
          >
            <source src={Medical_Video} type="video/mp4" />
            Your browser does not support the video tag.
          </video>

          <div style={{ position: "relative", zIndex: 2 }}>
            <div
              className="sets-apart-heading"
              style={{
                fontWeight: "700",
                fontSize: "30px",
                display: "flex",
                justifyContent: "space-around",
                paddingBottom: "30px",
                marginLeft: "15%",
                textDecoration: "underline",
                
              }}
            >
              What Sets Us Apart
            </div>

            <div
              className="sets-apart-carousel"
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "10px",
              }}
            >
              <div
                className="sets-apart-carousel-container"
                style={{
                  display: "flex",
                  gap: "16px",
                  overflow: "visible",
                  position: "relative",
                  paddingTop: "40px",
                  width: "max-content",
                  paddingLeft: "8px",
                }}
              >
                {services.map((service, index) => (
                  <div
                    key={index}
                    className="sets-apart-card"
                    style={{
                      width: "280px",
                      height: "270px",
                      borderRadius: "16px",
                      background:
                        "radial-gradient(circle at 20% 20%, #ddfeff, #fbfaff, #ddfeff)",
                      backgroundSize: "200% 200%",
                      backgroundPosition: "center",
                      position: "relative",
                      boxShadow: "0 4px 10px rgba(0, 0, 0, 0.08)",
                      padding: "30px 20px 20px 20px",
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "space-between",
                      transition: "transform 0.3s ease, box-shadow 0.3s ease",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = "scale(1.1)";
                      e.currentTarget.style.boxShadow =
                        "0 8px 20px rgba(0, 0, 0, 0.12)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = "scale(1)";
                      e.currentTarget.style.boxShadow =
                        "0 4px 10px rgba(0, 0, 0, 0.08)";
                    }}
                  >
                    <div
                      style={{
                        position: "absolute",
                        top: "-24px",
                        left: "20px",
                        zIndex: 2,
                      }}
                    >
                      <div
                        style={{
                          width: "48px",
                          height: "48px",
                          borderRadius: "5px",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          color: "white",
                          fontSize: "22px",
                          backgroundColor: service.bgColor,
                        }}
                      >
                        {service.icon}
                      </div>
                    </div>
                    <div>
                      <div
                        className="sets-apart-card-title"
                        style={{
                          fontWeight: 600,
                          fontSize: "16px",
                          marginBottom: "6px",
                        }}
                      >
                        {service.title}
                      </div>
                      <div
                        className="sets-apart-card-description"
                        style={{
                          fontSize: "14px",
                          color: "#444",
                          marginBottom: 0,
                        }}
                      >
                        {service.description}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}