import React from 'react'

const HeathVoyage = () => {
  return (
    <div>HeathVoyage</div>
  )
}

export default HeathVoyage