import React, { useEffect } from "react";
import logo from "../../assets/img/PNG.png";

export default function Footer() {
  useEffect(() => {
    const style = document.createElement("style");
    style.textContent = `
      @media (max-width: 768px) {
        .footer-container {
          padding: 1rem 0.5rem !important;
          flex-direction: column !important;
          align-items: center !important;
        }
        .footer-logo {
          width: 150px !important;
        }
        .footer-tagline {
          font-size: clamp(12px, 3vw, 16px) !important;
        }
        .footer-buttons {
          flex-direction: column !important;
          align-items: center !important;
          gap: 8px !important;
          margin-top: 1rem !important;
          
        }
        .footer-button {
        display: flex !important;
        margin: 0.25rem !important;
          width: 100% !important;
          max-width: 300px !important;
          text-align: center !important;
          padding: 0.5rem 0.75rem !important;
          height: 3rem !important;
          font-size: clamp(16px, 2.5vw, 18px) !important;
        }
        .footer-copyright {
          text-align: center !important;
          font-size: clamp(10px, 2.5vw, 14px) !important;
          padding: 0.5rem !important;
        }
      }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  return (
    <>
      <footer className="relative bg-blueGray-200 ">
        
        <div className="footer-container" style={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", flexWrap: "wrap" }}>
          <div className="footer-logo">
            <img
              alt="..."
              src={logo}
              style={{ width: "200px", marginTop: "20px" }}
            />
            <div className="footer-tagline" style={{ color: "#fa6904", fontSize: "1rem", fontFamily: "Helvetica, sans-serif" }}>Decoding Age. Designing Longevity</div>
          </div>
          <div className="footer-buttons mt-6 lg:mb-0 mb-6">
            <button
              className="footer-button py-1 px-4 bg-white text-lightBlue-400 shadow-lg font-normal h-10 items-center justify-center align-center rounded-full outline-none focus:outline-none mr-2"
              type="button"
            >
              Our Solutions
            </button>
            <button
              className="footer-button py-1 px-4 bg-white text-lightBlue-400 shadow-lg font-normal h-10 items-center justify-center align-center rounded-full outline-none focus:outline-none mr-2"
              type="button"
            >
              Health Voyage
            </button>
            <button
              className="footer-button py-1 px-4 bg-white text-lightBlue-400 shadow-lg font-normal h-10 items-center justify-center align-center rounded-full outline-none focus:outline-none mr-2"
              type="button"
            >
              Blogs & Community
            </button>
            <button
              className="footer-button py-1 px-4 bg-white text-lightBlue-400 shadow-lg font-normal h-10 items-center justify-center align-center rounded-full outline-none focus:outline-none mr-2"
              type="button"
            >
              Experts
            </button>
            <button
              className="footer-button py-1 px-4 bg-white text-lightBlue-400 shadow-lg font-normal h-10 items-center justify-center align-center rounded-full outline-none focus:outline-none mr-2"
              type="button"
            >
              Contact / Locations
            </button>
          </div>
          <hr className="my-6 border-blueGray-300" />
          <div className="footer-copyright flex flex-wrap items-center md:justify-between justify-center">
            <div className="w-full md:w-3/12 px-4 mx-auto text-center">
              <div className="text-sm text-blueGray-500 font-semibold py-1">
                Copyright © {new Date().getFullYear()}
              </div>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}